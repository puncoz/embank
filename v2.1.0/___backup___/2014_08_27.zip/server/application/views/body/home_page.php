<?php $this->load->view('header') ?>
<?php $this->load->view('body_top') ?>
				<!-- Brown Splash -->
                <section class="splash-content">
                    <div class="cnt">
                        <h1>When it comes to Money on Internet,<br />
                        easier system with full poof security is the most.</h1>
                        <p>So, yeah, emBank promises complete payment solution with a focus on easier usability with high end security system<br/>
                        Where-ever you wants, whenever you wants, always with a smile. </p>
                        <p>Why else should you give it a shot? We guarrentied to make your life easier by providing all your monetory in your finger tips. emBank provides complete payment option for buying any goods online, paying utility bills and the functions and features count on. </p>
                    </div>
                    <div class="btn submit"><a href="<?php echo site_url("index.php/users/register") ?>">Register Now</a></div>
                    <div class="clear"></div>
                </section>
                
                
                <div class="services-title">Our Services</div>
                <div class="services"><div class="carousel">
                    <ul>
                        <li><img src="images/slides/partner/ic_1.jpg" alt="bank-of-kathmandu" /></li>
                        <li><img src="images/slides/partner/ic_2.jpg" alt="everest-bank" /></li>
                        <li><img src="images/slides/partner/ic_3.jpg" alt="global-ime-bank" /></li>
                        <li><img src="images/slides/partner/ic_1.jpg" alt="kumari-bank" /></li>
                        <li><img src="images/slides/partner/ic_2.jpg" alt="laxmi-bank" /></li>
                        <li><img src="images/slides/partner/ic_3.jpg" alt="nepal-investment-bank" /></li>
                        <li><img src="images/slides/partner/ic_1.jpg" alt="bank-of-kathmandu" /></li>
                        <li><img src="images/slides/partner/ic_2.jpg" alt="everest-bank" /></li>
                        <li><img src="images/slides/partner/ic_3.jpg" alt="global-ime-bank" /></li>
                        <li><img src="images/slides/partner/ic_1.jpg" alt="kumari-bank" /></li>
                        <li><img src="images/slides/partner/ic_2.jpg" alt="laxmi-bank" /></li>
                        <li><img src="images/slides/partner/ic_3.jpg" alt="nepal-investment-bank" /></li>
                    </ul></div>
                    <button class="prev">&lt;&lt;</button>
					<button class="next">&gt;&gt;</button>
                </div>
<?php $this->load->view('body_bottom') ?>
<?php $this->load->view('footer') ?>