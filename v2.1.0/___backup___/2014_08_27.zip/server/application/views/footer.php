
            <footer>
            	Copyright &copy; 2014 emBank. All rights reserved.
            </footer>
            
        </section>
        
        <!-- pre-load images for hover states -->
        <div><img src="<?php echo site_url("themes/images/bg_button_over.jpg") ?>" alt="" class="preload" /></div>
        <!-- end: pre-load -->
        
        <script type="text/javascript" src="<?php echo site_url("themes/scripts/slider.js") ?>"></script>
    </body>
</html>