<?php
	echo bin2hex(openssl_random_pseudo_bytes(3));
?>